# BibliotecaReact-v2
Esse é uma simulação que foi criada para representar uma biblioteca de livros






Aqui temos o home que é a caixa de entrada aonde os livros cadastrados irão ficar
![WhatsApp Image 2023-03-01 at 16 41 53](https://user-images.githubusercontent.com/94478634/222258432-cbbd0757-7e32-4bf8-b575-94d080a04137.jpeg)






![WhatsApp Image 2023-03-01 at 16 42 02](https://user-images.githubusercontent.com/94478634/222258467-a030a503-9853-4954-b6cf-fc881198923d.jpeg)






![WhatsApp Image 2023-03-01 at 16 42 13](https://user-images.githubusercontent.com/94478634/222258502-31659e63-80c7-4691-977d-7c710a499aa8.jpeg)





![WhatsApp Image 2023-03-01 at 16 42 26](https://user-images.githubusercontent.com/94478634/222258552-d6bc3adb-4a19-4f02-97df-facf7b2fd829.jpeg)





![WhatsApp Image 2023-03-01 at 16 42 54](https://user-images.githubusercontent.com/94478634/222258575-ea12f5bb-d085-40b0-b35d-c2e8c62ced8c.jpeg)




![WhatsApp Image 2023-03-01 at 16 43 09](https://user-images.githubusercontent.com/94478634/222258599-279a009d-c5d9-4c32-9b34-77c43f014a47.jpeg)









![WhatsApp Image 2023-03-01 at 16 43 16](https://user-images.githubusercontent.com/94478634/222258640-03940b83-135b-4957-af94-ce9df47463c2.jpeg)






![WhatsApp Image 2023-03-01 at 16 43 24](https://user-images.githubusercontent.com/94478634/222258656-3da7c53b-708f-4391-a35b-5379cf389bc2.jpeg)









![WhatsApp Image 2023-03-01 at 16 43 38](https://user-images.githubusercontent.com/94478634/222258697-d569988f-827e-418d-9460-2b8ce04e78e8.jpeg)












![WhatsApp Image 2023-03-01 at 16 43 49](https://user-images.githubusercontent.com/94478634/222258726-52592d23-ff85-4a0e-8bae-9e4a40741add.jpeg)








![WhatsApp Image 2023-03-01 at 16 43 56](https://user-images.githubusercontent.com/94478634/222258762-8da578ab-30d1-46e3-ab1a-c3351aa8ab5f.jpeg)









